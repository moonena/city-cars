import { getAuth, signInWithEmailAndPassword } from "https://www.gstatic.com/firebasejs/10.12.0/firebase-auth.js";
import { app } from './firebase.js';

const auth = getAuth(app);

document.getElementById("login-btn").addEventListener("click", () => {
  const email = document.getElementById("email").value.trim();
  const password = document.getElementById("password").value.trim();

  if (!email || !password) {
    alert("الرجاء إدخال البريد وكلمة المرور.");
    return;
  }

  signInWithEmailAndPassword(auth, email, password)
    .then((userCredential) => {
      alert("✅ تم تسجيل الدخول بنجاح");
      window.location.href = "home.html";
    })
    .catch((error) => {
      alert("❌ خطأ: " + error.message);
    });
});